import logging


# ANSI escape sequences for colors
class LogColors:
    DEBUG = '\033[94m'  # Blue
    INFO = '\033[92m'   # Green
    WARNING = '\033[93m' # Yellow
    ERROR = '\033[91m'   # Red
    CRITICAL = '\033[1;31m'  # Bold Red
    RESET = '\033[0m'    # Reset color

# Custom formatter
class CustomFormatter(logging.Formatter):
    format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s (%(filename)s:%(lineno)d)"

    FORMATS = {
        logging.DEBUG: LogColors.DEBUG + format + LogColors.RESET,
        logging.INFO: LogColors.INFO + format + LogColors.RESET,
        logging.WARNING: LogColors.WARNING + format + LogColors.RESET,
        logging.ERROR: LogColors.ERROR + format + LogColors.RESET,
        logging.CRITICAL: LogColors.CRITICAL + format + LogColors.RESET
    }

    def format(self, record):
        log_fmt = self.FORMATS.get(record.levelno)
        formatter = logging.Formatter(log_fmt, datefmt='%Y-%m-%d %H:%M:%S')
        return formatter.format(record)

# Setup logger
def setup_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)  # Set to lowest level to capture all types of logs

    # Create console handler with a higher log level
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)

    # Use the custom formatter
    ch.setFormatter(CustomFormatter())

    # Add the handler to the logger
    logger.addHandler(ch)
    return logger

# Example usage
if __name__ == "__main__":
    logger = setup_logger("ExampleLogger")
    logger.debug("This is a debug message")
    logger.info("This is an info message")
    logger.warning("This is a warning message")
    logger.error("This is an error message")
    logger.critical("This is a critical message")
