#!/bin/bash

echo "hi"
sleep 1
echo "hi"
sleep 1
echo "hi"
sleep 1
echo "hi"
# Default filename
default_filename="/home/$USER/.ssh/id_rsa"

# Prompt user for a filename, with default option shown in the prompt
read -p "Enter a file in which to save the key ($default_filename): " filename

# Use default filename if user input is empty
filename=${filename:-$default_filename}

# Output the filename chosen (or the default)
echo "Key will be saved in: $filename"

read -p "Enter your username: " username

echo "gotUser: $username"
