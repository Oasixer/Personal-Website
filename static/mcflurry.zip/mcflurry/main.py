import asyncio
import json
import sys
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any
import argparse

if sys.version_info >= (3, 11): # proper Self for type hinting
    from typing import Self
else:
    class Self: # workaround
        _ = 1

# Using pathlib to get the directory of the current script and convert it to a string
sys.path.append(str(Path(__file__).resolve().parent))

from mcflurry.command_output import Command
from mcflurry.engine import Engine, EvaluatorType, Program, RunnerType, Step
from mcflurry.logger import Logger, setup_logger

# argparse for emptying steps dir
parser = argparse.ArgumentParser()
parser.add_argument('--empty_steps_dir', action='store_true')
empty_steps_dir = parser.parse_args().empty_steps_dir

async def main():
    log: Logger = setup_logger('mcf', '')
    engine = Engine(log, empty_steps_dir)
    await engine.connect()
    await engine.run()
    
if __name__ == '__main__':
    asyncio.run(main())
