#!/bin/bash
#
echo "hi"
sleep 1
echo "hi"
sleep 1
echo "hi"
echo "hi"
echo "hi"
echo "hi"

# exit with status 0
exit 1

