from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Self

import json5

from . import EvaluatorType, RunnerType, replace_tilde_home
from .command_output import Command
from .interaction import Interaction
from .logger import Logger

# from . import 
LOG_WIDTH = 56

def command_to_filename(command: str, already_used: set) -> str:
    # List of characters to remove completely
    remove_chars = '/\\0*?"<>|:'
    
    # Replace spaces with underscores and remove specific problematic characters
    safe_filename = command.replace(' ', '_')
    safe_filename = ''.join(c for c in safe_filename if c not in remove_chars)
    
    while safe_filename[0] == '.':
        safe_filename = safe_filename[1:]
    
    # Optionally limit the length of the filename
    # For example, to 255 characters, common max filename length on many filesystems
    max_length = 255
    if len(safe_filename) > max_length:
        safe_filename = safe_filename[:max_length]
    
    while safe_filename in already_used:
        safe_filename = f'{safe_filename}_'
    already_used.add(safe_filename)
    return safe_filename

@dataclass
class StepResult:
    succeeded: bool
    ret_lines: list[str]
    # eval_method: EvaluatorType
    reason: str

def trim_strlen(s: str, max_len: int) -> str:
    if len(s) > max_len:
        return s[:max_len] + '...'
    return s

class RestartRequired(Enum):
    SHELL = "SHELL"
    PC = "PC"
    NONE = "NONE"

@dataclass
class Step:
    command: Command
    runner_type: RunnerType
    # interactive: bool
    cd: Path
    eval_type: EvaluatorType
    eval_pat: str
    program: Any # should actually be Program lol
    n: int
    restart_required: bool # require restart after step
    log: Logger

    def log_step(self):
        log_lines = [f'{self.n: <2}:  ^   {trim_strlen(self.command.line, 40)}  ',
                    f'     |',
                    f'     |____________ cd {self.cd} &&       ',
                    f'  [fails: {self.count_fails()} ] [{self.runner_type.name}]  [{self.eval_type.name}]',
        ]
        if self.command.interactions:
            log_lines.append(f'  [{len(self.command.interactions)} Interactions]:')
            for interact in self.command.interactions:
                log_lines.append(f'    "{interact.pat}" -> "{interact.inp}"')
        for line in log_lines:
            self.log.step(f'{line: <{LOG_WIDTH}}')

    @classmethod
    def from_json_dict(cls, json_dict: dict, program: Any, log: Logger):
        # print(json_dict)
        cwd = program.cwd
        cd_abs = json_dict.get('cd_abs', None)
        if cd_abs is not None:
            cwd = Path(replace_tilde_home(cd_abs))

        cd_rel = json_dict.get('cd_rel', None)
        if cd_rel is not None:
            if cd_abs is not None:
                raise Exception('not allowed to have both kinds of cd')
            cwd = cwd / cd_rel

        restart_required = RestartRequired(
                json_dict.get('restart_required',
                              RestartRequired.NONE.value))
        

        interactions = []
        for json_interact in json_dict.get('interactions', []):
            interactions.append(Interaction.from_json_dict(json_interact))

        # if not cwd.exists():
        #     log.warn(f"dir {cwd} doesn't exist")

        # cd = program.cwd if cd is None else program.cwd / cd

        sudo = json_dict.get('sudo', False)
        if sudo:
            runner_type = RunnerType.SUDO
        else:
            runner_type = RunnerType.NON_SUDO

        eval_type = EvaluatorType(json_dict.get('eval_type', EvaluatorType.CHECK_RET.value))
        
        return cls(
            command=Command(json_dict['cmd'], cwd=cwd, interactions=interactions),
            runner_type=runner_type,
            cd=cwd,
            eval_type=eval_type,
            eval_pat=json_dict.get('eval_pat',''),
            program=program,
            n=len(program.steps),
            restart_required=restart_required,
            log=log
        )

    @property
    def filename(self):
        if hasattr(self, 'decided_filename'):
            return self.decided_filename
        
        # name = command_to_filename(self.command.line, self.program.step_meta_filenames)
        datetime_str = datetime.now().strftime("%Y-%m-%d")#-%H-%M-%S")
        name = f'{datetime_str}'
        self.decided_filename = name
        return name
    
    @property
    def success_filepath(self):
        return self.program.step_attempts_dir / f"{self.n}_{self.filename}_SUCC"
    
    def fail_path(self, i: int):
        return self.program.step_attempts_dir / f'{self.n}_{self.filename}_FAIL_{i}'

    def available_fail_filepath(self):
        for i in range(9999):
            if not (p := self.fail_path(i)).exists():
                return p
        raise Exception('too many failures')
    
    def count_fails(self):
        for i in range(9999):
            if not self.fail_path(i).exists():
                return i
        raise Exception('counted too many failures')
    
    @property
    def installed(self):
        return self.success_filepath.exists()
    
    def report_failure(self, res: StepResult):
        with open(self.available_fail_filepath(), 'a+') as f:
            f.writelines([f'PROGRAM: {self.program.name}\n\n',
                          f'STEP:\n',
                          f'{self.command.line}\n\n',
                          f'FAILED:\n',
                          f'reason={res.reason}\n\n'
                          f'OUTPUT:\n'])
            f.writelines(res.ret_lines)
        msg = f"step {self.n} failed"
        self.log.failed(f'{msg: <{LOG_WIDTH}}')

    def mark_installed(self, res: StepResult):
        if not self.success_filepath.exists():
            with open(self.success_filepath, 'a+') as f:
                f.writelines([f'Program: {self.program.name}\n',
                              f'STEP:\n',
                              f'{self.command.line}\n\n',
                              f'SUCCEEDED: {res.succeeded}\n',
                              f'OUTPUT:\n'
                              ])
                f.writelines(res.ret_lines)
        # self.log.success(f"step {self.n} installed")
        msg = f"STEP {self.n} INSTALLED"
        self.log.success(f'{msg: <{LOG_WIDTH}}')
