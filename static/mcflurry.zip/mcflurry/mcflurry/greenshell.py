import asyncio
import logging
import select
import subprocess
import threading

import pexpect
import requests

from . import NOT_DONE_RET, TIMEOUT_RET
from .command_output import Command, OutputLine
from .logger import Logger


class GreenShell:
    def __init__(self, log: Logger):
        self.log = log

    # yield each output line in stdout.
    async def run_interactive(self, command: Command):
        interactions = command.interactions

        print(f'{command.line_with_cd()}')
        process = pexpect.spawn(f'bash -c "{command.line_with_cd()}"', encoding='utf-8')

        executed_interact_inp = None

        for _ in range(9999):
            index = process.expect([
                    pexpect.EOF,
                    pexpect.TIMEOUT,
                ] + [i.pat for i in interactions],
                timeout = 3
            )
            try:
                ret_code_timeout = None
                if index == 0:  # EOF reached
                    print('End of file detected. Exiting.')
                    break
                elif index == 1:  # Timeout - no more data expected quickly
                    ret_code_timeout = TIMEOUT_RET
                    # print('Timeout. Giving up...')
                    # print(f'(buffered:) {process.before.strip()}')
                    for line in process.before.strip().split("\n"):
                        if "\r\n" in line:
                            print('detected \\r\\n in line, replacing')
                            line.replace('\r\n', 'RN')
                        # print(f'check {line} against {executed_interact_inp}\n\n', flush=True)
                        if line.strip() == executed_interact_inp:
                            yield OutputLine(line=line,
                                             done=False,
                                             ret=NOT_DONE_RET,
                                             input=True)
                        else:
                            yield OutputLine(line=line,
                                             done=False,
                                             ret=NOT_DONE_RET,
                                             input=False)
                    break

                    # print('[TODO]: yield output here!!!')
                for n, interact in enumerate(interactions):
                    if index == n + 2:
                        # print(f'matched {interact.pat} against {process.after}, send {interact.inp}')
                        process.sendline(interact.inp)
                        for line in process.before.strip().split('\n'):
                            yield OutputLine(line=line,
                                             done=False,
                                             ret=NOT_DONE_RET,
                                             input=False)
                        for line in process.after.split('\n'):
                            yield OutputLine(line=line,
                                             done=False,
                                             ret=NOT_DONE_RET,
                                             input=False)
                        # yield OutputLine(line=interact.inp,
                        #                  done=False,
                        #                  ret=NOT_DONE_RET,
                        #                  input=True)
                        executed_interact_inp = interact.inp
            except pexpect.exceptions.EOF:
                print("Reached end of file.")
                break
            except pexpect.exceptions.TIMEOUT:
                print("Timeout occurred.")
                break
    
        process.close()
        ret_code = process.exitstatus
        if ret_code_timeout is not None:
            ret_code = ret_code_timeout

        yield OutputLine(line='', done=True, ret=ret_code, input=False)
    # non-interactive
    # yield each output line... what does it do when asked for an interaction?
    # only an async function because it must present the same signature as
    # redshell running commands through the socket
    async def run_normal(self, command: Command):
        # process = subprocess.Popen(command.line_with_cd(),
        #                            shell=True,
        #                            stdout=subprocess.PIPE,
        #                            stderr=subprocess.STDOUT,
        #                            text=True)
        # for line in process.stdout:
        #     print(line)
        #     # print(line, flush=True)
        #     yield OutputLine(line=line,
        #                      done=False,
        #                      ret=NOT_DONE_RET,
        #                      input=False)
        # # print('now waiting')
        #
        # # Wait for the command to complete
        # process.wait()
        # yield OutputLine(line='', done=True, ret=process.returncode, input=False)

        print(f'{command.line_with_cd()}')
        cmd_list = [f'bash', '-c', f'"{command.line_with_cd()}"']
        timeout_sec = 3

        # process = await asyncio.create_subprocess_exec(*cmd_list,
        process = await asyncio.create_subprocess_shell(command.line_with_cd(),
                                   shell=True,
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT,
                                   )

        # Read line (sequence of bytes ending with b'\n') asynchronously
        timed_out = False
        while True:
            try:
                line = await asyncio.wait_for(process.stdout.readline(), timeout_sec)
            except asyncio.TimeoutError:
                timed_out = True
                process.kill() # Timeout or some criterion is not satisfied
                yield OutputLine(line='',
                                 done=True,
                                 ret=TIMEOUT_RET,
                                 input=False)
                break
            if not line: # EOF
                print('EOF detected')
                break
            else:
                yield OutputLine(line=line.decode(),
                                  done=False,
                                  ret=NOT_DONE_RET,
                                  input=False)
        if not timed_out:
            ret_code = await process.wait()
            yield OutputLine(line='',
                             done=True,
                             ret=ret_code,
                             input=False)
            process.kill()

    async def run_normal2(self, command: Command):
        interactions = command.interactions

        print(f'{command.line_with_cd()}')
        process = pexpect.spawn(f'bash -c "{command.line_with_cd()}"', encoding='utf-8')

        executed_interact_inp = None

        for _ in range(9999):
            index = process.expect([
                    pexpect.EOF,
                    pexpect.TIMEOUT,
                ] + ['\n'],
                timeout = 3
            )
            try:
                ret_code_timeout = None
                if index == 0:  # EOF reached
                    print('End of file detected. Exiting.')
                    break
                elif index == 1:  # Timeout - no more data expected quickly
                    ret_code_timeout = TIMEOUT_RET
                    # print('Timeout. Giving up...')
                    # print(f'(buffered:) {process.before.strip()}')
                    for line in process.before.strip().split("\n"):
                        yield OutputLine(line=line,
                                         done=False,
                                         ret=NOT_DONE_RET,
                                         input=False)
                    break

                if index == 2: # newline
                    for line in process.before.strip().split('\n'):
                        yield OutputLine(line=line,
                                         done=False,
                                         ret=NOT_DONE_RET,
                                         input=False)
                    # for line in process.after.split('\n'):
                    #     yield OutputLine(line=line,
                    #                      done=False,
                    #                      ret=NOT_DONE_RET,
                    #                      input=False)
            except pexpect.exceptions.EOF:
                print("Reached end of file.")
                break
            except pexpect.exceptions.TIMEOUT:
                print("Timeout occurred.")
                break
    
        process.close()
        ret_code = process.exitstatus
        if ret_code_timeout is not None:
            ret_code = ret_code_timeout

        yield OutputLine(line='', done=True, ret=ret_code, input=False)

    async def run_step_yield_output(self, command: Command):
        # Start the command
        if command.interactions:
            runner = self.run_interactive
        else:
            runner = self.run_normal2

        async for output_line in runner(command):
            yield output_line


# Example usage, replace `<your-flask-app-ip-or-hostname>` with the actual IP address or hostname where your Flask app is running
# Example usage
command = "echo Hello, world!"
command = "blabla"
command = "ping -c 4 google.com"
command = "echo Hello, world!"
# call_command_endpoint(command)

# stream_shell_command(command)
# run_shell_command(command)
