import re
from dataclasses import dataclass


@dataclass
class Interaction:
    pat: str
    inp: str
    
    @classmethod
    def from_json_dict(cls, json_dict: dict):
        if 'pat' not in json_dict:
            print(f'invalid json (full): {json_dict}')
            raise Exception('invalid json interaction, requires str(pat)')
        if 'input' not in json_dict:
            print(f'invalid json (full): {json_dict}')
            raise Exception('invalid json interaction, requires str(input)')
        return cls(pat=json_dict['pat'], inp=json_dict['input'])

    def to_dict(self):
        dic = {}
        for k, v in self.__dict__.items():
            if k == "inp":
                k = "input"
            dic[k] = v
        return dic

    @property
    def compiled(self):
        return re.compile(self.pat)

    def matches(self, line):
        if self.compiled.search(line):
            return True
