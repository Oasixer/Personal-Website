import json
import sys
from dataclasses import dataclass
from pathlib import Path

from .interaction import Interaction

# import json5

if sys.version_info >= (3, 11): # proper Self for type hinting
    from typing import Self
else:
    class Self: # workaround
        _ = 1

@dataclass
class Command:
    line: str
    cwd: Path
    interactions: list[Interaction]

    @classmethod
    def from_json(cls, json_str: str) -> Self:
        data = json.loads(json_str)
        return cls(data['line'], Path(data['cwd']),
                   [Interaction.from_json_dict(i) for i in data['interactions']])

    def to_json(self) -> str:
        return json.dumps({'line': self.line, 'cwd': f'{self.cwd}',
                           'interactions': [i.to_dict() for i in self.interactions]})

    def line_with_cd(self):
        return f'cd {self.cwd} && {self.line}'

@dataclass
class OutputLine:
    line: str
    done: bool
    ret: int
    input: bool

    @classmethod
    def from_json(cls, json_str: str) -> Self:
        # print('json_str')
        # print(json_str)
        data = json.loads(json_str)
        return cls(line=data['line'],
                   done=data['done'],
                   ret=data['ret'],
                   input=data['input'])

    def to_json(self) -> str:
        return json.dumps(self.__dict__)
