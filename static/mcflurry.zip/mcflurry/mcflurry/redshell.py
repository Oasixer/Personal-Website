import asyncio
import json

from .command_output import Command, OutputLine
from .logger import Logger


class RedShell:
    def __init__(self, host: str, port: int, log: Logger):
        self.host = host
        self.port = port
        self.log = log
        self.reader = None
        self.writer = None

    async def connect(self):
        self.reader, self.writer = await asyncio.open_connection(self.host, self.port)

    async def run_step_yield_output(self, command: Command):
        self.writer.write(command.to_json().encode())
        await self.writer.drain()
        while True:
            line = await self.reader.readline()
            if len(line) > 0:
                # self.log.info(f'GOT LINE: {line}')
                output_line = OutputLine.from_json(line.decode().strip())
                yield output_line
                if output_line.done:
                    break
