import datetime
import logging
from pathlib import Path

from colorlog import ColoredFormatter

# Step 1: Define a new log level
PROGRAM_LEVEL = 35  # Numeric value between INFO (20) and ERROR (40)
STEP_LEVEL = 34  # Numeric value between INFO (20) and ERROR (40)
ENGINE_LEVEL = 36  # Numeric value between INFO (20) and ERROR (40)
SUCCESS_LEVEL = 37  # Numeric value between INFO (20) and ERROR (40)
FAILED_LEVEL = 38  # Numeric value between INFO (20) and ERROR (40)
logging.addLevelName(ENGINE_LEVEL, 'ENGINE')
logging.addLevelName(STEP_LEVEL, 'STEP')
logging.addLevelName(PROGRAM_LEVEL, 'PROGRAM')
logging.addLevelName(SUCCESS_LEVEL, 'SUCCESS')
logging.addLevelName(FAILED_LEVEL, 'FAILED')

Logger = logging.Logger

def generate_custom_log_fn(level):
    def log_fn(self, message, *args, **kwargs):
        if self.isEnabledFor(level):
            # By setting stacklevel to 2, Python's logger will look one level up in the stack
            # from the current function to find where the log call originated.
            self._log(level, message, args, kwargs, stacklevel=2)
    return log_fn
        
Logger.program = generate_custom_log_fn(PROGRAM_LEVEL)
Logger.step = generate_custom_log_fn(STEP_LEVEL)
Logger.failed = generate_custom_log_fn(FAILED_LEVEL)
Logger.success = generate_custom_log_fn(SUCCESS_LEVEL)
Logger.engine = generate_custom_log_fn(ENGINE_LEVEL)

# Adding the custom method to the Logger class

def generate_safe_filename(prefix="", suffix=""):
    now = datetime.datetime.now()
    datetime_str = now.strftime("%Y-%m-%d-%H-%M-%S")
    filename = f"{prefix}{datetime_str}_{suffix}.txt"
    return filename

def setup_logger(name: str, module_id: str, logs_dir="./mcflurry_logs") -> logging.Logger:
    log_file = logs_dir + "/" + generate_safe_filename(suffix=module_id)
    log_dir_path = Path(logs_dir)
    if not log_dir_path.exists():
        log_dir_path.mkdir()

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    # Configure formatter with color for the new 'PURPLE' level
    formatter = ColoredFormatter(
        "%(log_color)s%(asctime)s.%(msecs)03d - %(levelname)s - %(message)s "
        "(%(filename)s:%(lineno)d)%(reset)s",
        datefmt='%Y-%m-%d %H:%M:%S',
        log_colors={
            'DEBUG': 'cyan',
            'INFO': 'green',
            'WARNING': 'yellow',
            'ERROR': 'red',
            'CRITICAL': 'red,bg_black',
            'PROGRAM': 'black,bg_cyan',
            'STEP': 'black,bg_purple',
            'SUCCESS': 'black,bg_green',
            'FAILED': 'red,bg_black',
            'ENGINE': 'black,bg_red',
        }
    )

    # Console handler
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

    # File handler
    if not any(isinstance(h, logging.FileHandler) for h in logger.handlers):
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(logging.Formatter(
            "%(asctime)s.%(msecs)03d - %(levelname)s - %(message)s "
            "(%(filename)s:%(lineno)d)",
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        logger.addHandler(file_handler)

    return logger
