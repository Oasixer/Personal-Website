import asyncio
import json
from dataclasses import dataclass

@dataclass
class OutputLine:
    line: str
    done: bool
    ret: int

    @classmethod
    def from_json(cls, json_str: str):
        data = json.loads(json_str)
        return cls(data['line'], data['done'], data['ret'])

    def to_json(self) -> str:
        return json.dumps(self.__dict__)

@dataclass
class Command:
    line: str

    def to_json(self) -> str:
        return json.dumps({'line': self.line})

class SocketManager:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.reader = None
        self.writer = None

    async def connect(self):
        self.reader, self.writer = await asyncio.open_connection(self.host, self.port)

    async def send_command(self, command: Command):
        self.writer.write(command.to_json().encode())
        await self.writer.drain()

    async def receive_response(self):
        while True:
            line = await self.reader.readline()
            output_line = OutputLine.from_json(line.decode().strip())
            yield output_line
            if output_line.done:
                break
