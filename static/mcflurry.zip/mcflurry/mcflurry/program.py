from dataclasses import dataclass
from pathlib import Path
from typing import Any, Self

import json5

from . import (HOME_DIR, EvaluatorType, RunnerType, program_data_dir,
               replace_tilde_home)
from .logger import Logger
from .step import Step

COMPLETED_FLAG_FILE = "completed"
LOG_WIDTH = 54

@dataclass
class Program:
    name: str
    steps: list[Any]
    deps: list[str] # list of dep program names, used in LUT
    cwd: str
    step_meta_filenames: set

    def __init__(self, name: str, steps: list[Any], deps: list[str], cwd: str, log: Logger):
        self.name = name
        self.steps = steps
        self.deps = deps
        self.cwd = cwd
        self.step_meta_filenames = set()
        self.log = log

    def log_program(self, log_steps=True):
        name_fill = '~'
        name = f"{name_fill*5} PROGRAM: {self.name} "
        log_lines = [f'{name:=<{LOG_WIDTH}}', f"  cwd: {self.cwd}", ""]
        for line in log_lines:
            self.log.program(f'{line: <{LOG_WIDTH}}')
        # self.log.program(f"  cwd: {self.cwd}")
        # self.log.info(f"  steps:")
        if log_steps:
            for step in self.steps:
                step.log_step()


    @property
    def meta_dir(self):
        dir = program_data_dir / self.name
        if not dir.exists():
            dir.mkdir()
        return dir

    @property
    def step_attempts_dir(self):
        dir = self.meta_dir / "step_attempts"
        if not dir.exists():
            dir.mkdir()
        return dir

    def empty_step_attempts_dir(self):
        ONLY_REMOVE_SUCCESSES = True
        for file in self.step_attempts_dir.iterdir():
            if ONLY_REMOVE_SUCCESSES and file.suffix == '_SUCC':
                file.unlink()

    def mark_uninstalled(self):
        completed_file = self.meta_dir / COMPLETED_FLAG_FILE
        if completed_file.exists():
            completed_file.unlink()
    
    def installed(self):
        if not program_data_dir.exists():
            raise Exception(f'Error: meta dir {program_data_dir} not found')
        if (self.meta_dir / COMPLETED_FLAG_FILE).exists():
            return True
        return False
    
    def mark_installed(self):
        (self.meta_dir / COMPLETED_FLAG_FILE).touch()


    @classmethod
    def from_json5_file(cls, json5_file: Path, log: Logger) -> Self:
        with open(json5_file, 'r') as f:
            data = json5.load(f)

        inst = cls(name=data['name'],
                   cwd=replace_tilde_home(data['cwd']),
                   steps=[],
                   deps=data.get('deps',[]),
                   log=log
       )

        for json_step in data['steps']:
            inst.steps.append(Step.from_json_dict(json_step, program=inst, log=log))

        return inst
        # return cls(data['line'], data['done'], data['ret'])
