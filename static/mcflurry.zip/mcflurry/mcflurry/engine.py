from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Self

from . import (NOT_DONE_RET, PORT, TIMEOUT_RET, EvaluatorType, RunnerType,
               program_data_dir)
from .command_output import Command
from .greenshell import GreenShell
from .logger import Logger
from .program import Program
from .redshell import RedShell
from .step import Step, StepResult

LOG_WIDTH = 60
# class InteractiveType(Enum):
#     SUDO = "SUDO"
#     NON_SUDO = "NON_SUDO"

def mark_success_suffix(file: str, fail: bool) -> str:
    return file + ('.FAIL' if fail else '.SUCC')


    
@dataclass
class Engine:
    red_shell: RedShell
    green_shell: GreenShell
    programs: dict[str, Program]
    log: Logger

    def __init__(self, log: Logger, empty_steps_dir:bool = False):
        self.red_shell = RedShell('localhost', PORT, log)
        self.green_shell = GreenShell(log)
        self.log = log
        self.programs = {}

        self.log.info(f"balls")
        self.log.warning(f"balls")
        self.log.error(f"balls")
        self.log.critical(f"balls")
        # self.log.debug(f':')
        log_msg = f'INIT: Scanning {program_data_dir}'
        self.log.engine(f'{log_msg: <{LOG_WIDTH}}')
        for item in program_data_dir.iterdir():
            if item.is_dir():
                # self.log.info(f'found program: {item}')
                for possible_json in item.iterdir():
                    if possible_json.suffix == '.json5':
                        # self.log.info(f'found json5')
                        program: Program = Program.from_json5_file(possible_json, log)
                        
                        if empty_steps_dir:
                            self.log.critical(f'~~~~~~~~~~~~~~~EMPTYING STEPS DIR~~~~~~~~~~~~~~~')
                            program.empty_step_attempts_dir()
                            self.log.critical(f'~~~~~~~~~~~~~~~MARKING UNINSTALLED~~~~~~~~~~~~~~')
                            program.mark_uninstalled()

                        program.log_program()


                        if program.name != possible_json.stem:
                            self.log.error(f'ERROR: <name={program.name}> != <{possible_json.stem}>.json5')
                            raise Exception(f'ERROR: <name={program.name}> != <{possible_json.stem}>.json5')
                        if program.name != item.stem:
                            self.log.error(f'ERROR: <name={program.name}> != program_data/<{item.stem}> (dirname)')
                            raise Exception(f'ERROR: <name={program.name}> != program_data/<{item.stem}> (dirname)')
                        self.programs[program.name] = program
        

    def program_deps_unmet(self, prog: Program) -> list[str]:
        unmet_deps = []
        for dep_name in prog.deps:
            if dep_name not in self.programs:
                raise Exception(f'dep{dep_name} not found in programs:{list(self.programs.keys())}')
            dep = self.programs[dep_name]


            if not dep.installed:
                self.log.warn(f"DEBUGPRINT[1]: engine.py:55: unmet dep: {dep_name}")
                unmet_deps.append(dep_name)
        return unmet_deps


    async def run(self):
        print()
        intro = '================================='
        self.log.engine(f"{intro:=<{LOG_WIDTH}}")
        self.log.engine(f"{'BEGIN ENGINE RUN': <{LOG_WIDTH}}")
        failed, skipped, already_installed, newly_installed = 0, 0, 0, 0
        for program in self.programs.values():
            program.log_program(log_steps=False)
            if program.installed():
                l = f'PROGRAM ALREADY INSTALLED'
                self.log.success(f'{l: <55}')
                already_installed += 1
                continue
            unmet_deps = self.program_deps_unmet(program)
            if unmet_deps:
                l = '{program.name} skipped due to unmet deps'
                self.log.failed(f'{l: <{LOG_WIDTH}}')
                skipped += 1
                continue

            succeeded_installing_program = True
            for step in program.steps:
                step.log_step()
                if step.installed:
                    l = f'STEP ALREADY INSTALLED'
                    self.log.success(f'{l: <60}')
                    continue

                res = await self.execute_step(step)
                if res.succeeded:
                    # self.log.info('succeeded')
                    step.mark_installed(res)
                    # install_step.
                    # mark_step_success(install_step)
                else:
                    self.log.error(f'step failed with {res.reason}')
                    step.report_failure(res)
                    succeeded_installing_program = False
                    break
            if succeeded_installing_program:
                newly_installed += 1
            else:
                failed += 1
        
        log_lines = [f"{'END ENGINE RUN': <60}",
                     f"  {newly_installed} programs newly installed",
                     f'  {already_installed} programs already installed',
                     f'  {failed} programs failed while installing',
                     f'  {skipped} programs skipped',
                     f'  {len(self.programs)} [ total programs ]'
        ]
        for i in log_lines: self.log.engine(f'{i: <60}')




    async def connect(self):
        await self.red_shell.connect()

    async def execute_step(self, step: Step) -> StepResult:
        # print(f'{step.command.line}')

        # favoring composition over inheritance here
        run_fun = self.red_shell.run_step_yield_output
        if step.runner_type is RunnerType.NON_SUDO:
            run_fun = self.green_shell.run_step_yield_output

        res_lines = []
        ret_code = None
        # async for output_line in runner(step.command):
        if step.command.line.startswith('MANUAL'):
            self.log.step(step.command.line)
            input('Press Enter when done')
            return StepResult(succeeded=True,
                              ret_lines=[],
                              reason="manual"
                              )
        async for output_line in run_fun(step.command):
            if output_line.done:
                ret_code = output_line.ret
                break
            if output_line.input:
                # FOR SOME REASON ALL THEM ARE PRINTING AS INPUT
                print(f'<<< {output_line.line.rstrip()}', flush=True)
            else:
                print(f'> {output_line.line.rstrip()}', flush=True)
            res_lines.append(output_line.line)

        step_result = evaluate_step(step.eval_type, ret_lines=res_lines, ret_code=ret_code)
        return step_result

def check_ret_code(ret_lines: list, ret_code: int) -> StepResult:
    # print(f'checking ret code: {ret_code}')
    if ret_code == 0:
        return StepResult(succeeded=True, ret_lines=ret_lines, reason='')
    if ret_code == TIMEOUT_RET:
        return StepResult(succeeded=False, ret_lines=ret_lines, reason=f'Timed out (more input required?)')
    return StepResult(succeeded=False, ret_lines=ret_lines, reason=f'Failed with code:{ret_code}')

def evaluate_step(eval_type: EvaluatorType, ret_code: int, ret_lines: str):
    if eval_type is EvaluatorType.CHECK_RET:
        return check_ret_code(ret_code=ret_code, ret_lines=ret_lines)
    raise Exception("invalid eval_type")



# def mark_step_success(step: Step):
    # step_filename = 
    # if not 
