# this is the instance running sudo shell commands

# I know that doing this as a flask app was not neccessary - there is probably an ok way
# to do this in python (executing a series of commands, some as the user and some as root (via sudo)
# (for example i know how to do this in bash), but whatever


import subprocess
import threading
from queue import Queue

from flask import Flask, jsonify, request

app = Flask(__name__)

def stream_command(command, queue):
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in process.stdout:
        queue.put(line)
    process.wait()
    queue.put(None)  # Signal the end of the stream

@app.route('/run-command', methods=['POST'])
def run_command():
    data = request.json
    command = data.get('command')
    
    if not command:
        return jsonify({"error": "No command provided"}), 400
    
    queue = Queue()
    thread = threading.Thread(target=stream_command, args=(command, queue))
    thread.start()

    def generate():
        while True:
            line = queue.get()
            if line is None: break
            yield line
    
    return app.response_class(generate(), mimetype='text/plain')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
