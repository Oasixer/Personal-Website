PORT=4999
NOT_DONE_RET = -16969
TIMEOUT_RET = -66996699
HOME_DIR="/home/k"

from enum import Enum
from pathlib import Path

program_data_dir = Path("./program_data")

class EvaluatorType(Enum):
    CHECK_RET = "CHECK_RET"
    CHECK_FILE_EXISTS = "CHECK_FILE_EXISTS" # check if some file exists ie. the program to be installed
    CHECK_WITH_STEP = "CHECK_WITH_STEP"
    # ie. if 

class RunnerType(Enum):
    SUDO = "SUDO"
    NON_SUDO = "NON_SUDO"

def replace_tilde_home(path_str: str) -> Path:
    if path_str.startswith('~/'):
        path_str = f'{HOME_DIR}{path_str[1:]}'
    return Path(path_str)

# from .command_output import Command, OutputLine
# from .engine import Engine
# from .greenshell import GreenShell
# from .logger import setup_logger
# from .program import Program
# from .redshell import RedShell
