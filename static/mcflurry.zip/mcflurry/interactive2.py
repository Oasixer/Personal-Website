# import pexpect
#
# # Path to your Bash script
# bash_script_path = './blah3.sh'
#
# # Start the Bash script with pexpect
# child = pexpect.spawn(f'{bash_script_path}', encoding='utf-8')
#
# # Wait for the prompt from the Bash script
# child.expect('Enter a file in which to save the key.*: ')
#
# # Before sending the input, print the prompt to verify it
# print('Prompt:', child.before + child.after)
#
# # Send the input 'test' followed by a newline
# child.sendline('test')
#
# # Wait for the output and print it
# child.expect(pexpect.EOF)
import pexpect

# Path to your Bash script
bash_script_path = './blah3.sh'

# Start the Bash script with pexpect
child = pexpect.spawn(f'bash {bash_script_path}', encoding='utf-8')

# List to capture all output for logging or later processing
all_output = []

while True:
    try:
        # Wait for any output until a timeout (none expected, so any output is captured)
        index = child.expect(['Enter a file in which to save the key.*: ', pexpect.EOF, pexpect.TIMEOUT], timeout=1)
        
        # Capture the output and append it to the list
        all_output.append(child.before)

        # Check if the specific prompt was matched
        if index == 0:  # 'Enter a file...' prompt is found
            print('Prompt detected:', child.before + child.after)
            print('askljdfslj')
            # Send the input 'test' followed by a newline
            child.sendline('test')
        elif index == 1:  # EOF reached
            print('End of file detected. Exiting.')
            break
        elif index == 2:  # Timeout - no more data expected quickly
            print('No more immediate output. Waiting...')
    except pexpect.exceptions.EOF:
        print("Reached end of file.")
        break
    except pexpect.exceptions.TIMEOUT:
        print("Timeout occurred.")
        break

# Print all captured output after interaction is complete
print("Full output from the script:")
print('\n'.join(all_output))

# Close the process
child.close()
