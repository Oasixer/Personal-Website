import pexpect

# Path to your Bash script
bash_script_path = './blah3.sh'

# Start the Bash script with pexpect
child = pexpect.spawn(f'bash -c "cd . && {bash_script_path}"', encoding='utf-8')

# List to capture all output for logging or later processing
all_output = []

while True:
    try:
        # Wait for any output until a timeout
        index = child.expect([
            pexpect.EOF, 
            pexpect.TIMEOUT,
            'Enter a file in which to save the key.*: ', 
            'Enter your username: ',
        ], timeout=1)

        # Capture the output and append it to the list
        all_output.append(child.before.strip())
        all_output.append(child.after)

        if index == 0:  # EOF reached
            print('End of file detected. Exiting.')
            break
        elif index == 1:  # Timeout - no more data expected quickly
            print('No more immediate output. Waiting...')
        elif index == 2:  # 'Enter a file...' prompt
            print('File save prompt detected.')
            child.sendline('testfile')
        elif index == 3:  # 'Enter your username' prompt
            print('Username prompt detected.')
            child.sendline('username')
    except pexpect.exceptions.EOF:
        print("Reached end of file.")
        break
    except pexpect.exceptions.TIMEOUT:
        print("Timeout occurred.")
        break

# Print all captured output after interaction is complete
print("Full output from the script:")
print(all_output)
# for output in all_output:
#     print(output)

# Close the process
child.close()
