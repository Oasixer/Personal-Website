import subprocess

# Path to the Bash script
bash_script_path = './blah3.sh'

# Start the subprocess with the ability to input data
# process = subprocess.Popen(['bash', bash_script_path], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
process = subprocess.Popen(['bash', bash_script_path], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)

# Send 'test' as the input followed by a newline to simulate pressing Enter
# output, errors = process.communicate(input='test\n')

# Print the output of the Bash script
# print(output)
for output in process.stdout:
    print(output)
