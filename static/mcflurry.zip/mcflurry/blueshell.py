import asyncio
import json
import signal
import socket
import sys
from dataclasses import dataclass

from mcflurry import PORT
from mcflurry.command_output import Command, OutputLine
from mcflurry.greenshell import GreenShell
from mcflurry.logger import Logger, setup_logger

# HOST = '192.168.2.216'
HOST = '127.0.0.1'

s_global = None

async def main():
    log: Logger = setup_logger('mcf', 'blu')
    green_shell = GreenShell(log)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('', PORT))
        s.listen()
        print(f"Listening for TCP connections on {HOST}:{PORT}...")

        global s_global
        s_global = s
        while True:
            client_socket, addr = s.accept()
            with client_socket:
                print(f"Connected by {addr}")
                while True:
                    data = client_socket.recv(1024)  # buffer size is 1024 bytes
                    if not data:
                        break
                    received_msg = data.decode('utf-8')
                    print(f"Received packet from {addr[0]}:{addr[1]}: {received_msg}")

                    command = Command.from_json(received_msg)

                    async for output_line in green_shell.run_step_yield_output(command):
                        # output_line = OutputLine.from_json(received_msg)
                        response_msg = f'{output_line.to_json()}\n'
                        print(f'sending output_line: {output_line}')


                        # response_msg = f"I received <{received_msg}> from <{addr[0]}:{addr[1]}>"
                        # print("Sending response message...")
                        client_socket.send(response_msg.encode('utf-8'))


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt: # this works btw!
        s_global.close()
        print("interrupted2")
